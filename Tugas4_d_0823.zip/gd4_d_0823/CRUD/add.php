<html>
<head>
    <title>Add Users</title>
</head>
 
<body>
    <a href="index.php">Go to Home</a>
    <br/><br/>
 
    <form action="add.php" method="post" name="form1">
        <table width="25%">
            <tr> 
                <td>Name</td>
                <td><input type="text" name="name"></td>
            </tr>
            <tr> 
                <td>Genre</td>
                <td><input type="text" name="genre"></td>
            </tr>
            <tr> 
                <td>Realese</td>
                <td><input type="text" name="realese"></td>
            </tr>
            <tr> 
                <td>Season</td>
                <td><input type="text" name="season"></td>
            </tr>
            <tr> 
                <td>Synopsis</td>
                <td><input type="text" name="synopsis"></td>
            </tr>
            <tr> 
                <td></td>
                <td><input type="submit" name="Submit" value="Add"></td>
            </tr>
        </table>
    </form>
    
    <?php
 
    
    if(isset($_POST['Submit'])) {
        $name = $_POST['name'];
        $genre = $_POST['genre'];
        $realese = $_POST['realese'];
        $season = $_POST['season'];
        $synopsis = $_POST['synopsis'];
        
        // include database connection file
        include_once("config.php");
                
        
        $result = mysqli_query($mysqli, "INSERT INTO users(name,genre,realese,season,synopsis) VALUES('$name','$genre','$realese','$season','$synopsis')");
        
        
        echo "User added successfully. <a href='index.php'>View Movie</a>";
    }
    ?>
</body>
</html>